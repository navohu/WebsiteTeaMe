document.getElementById("clickMe").onclick(function (){
	document.getElementById("turnmered").html("WEEEEE");
	console.log("DONE")
})